<?php
define('PAYU_API_KEY', '4Vj8eK4rloUd272L48hsrarnUA');
define('PAYU_API_LOGIN', 'kFV04G5eIQ87281');
define('PAYU_PUBLIC_KEY', 'PK789balM8Y0276COBVc9995PP');
define('PAYU_MERCHANT_ID', '508029');
define('PAYU_ACCOUNT_ID', '512321'); // Reemplazar con el Account ID correcto
define('PAYU_CURRENCY', 'COP');
define('PAYU_TEST_MODE', 1); // 1 para pruebas, 0 para producción
define('PAYU_RESPONSE_URL', 'http://localhost/shoop-local/views/response.php');
define('PAYU_CONFIRMATION_URL', 'http://localhost/shoop-local/views/confirmation.php');