<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Guía Educativa: Carga Masiva de Productos</title>
    <link rel="stylesheet" href="../CSS/styles.css">
</head>
<body>
    <div class="header">
        <h1>Guía para Carga Masiva de Productos</h1>
        <p>Procedimiento completo para registrar múltiples productos en el sistema</p>
    </div>

    <div class="guide-section">
        <h2>Introducción</h2>
        <p>Esta guía explica el proceso completo para realizar cargas masivas de productos mediante archivos Excel. Sigue cuidadosamente cada paso para garantizar resultados óptimos.</p>
        
        <div class="note">
            <strong>Recomendación:</strong> Antes de comenzar, prepara toda la información de los productos incluyendo imágenes nombradas consistentemente.
        </div>
    </div>

    <div class="guide-section">
        <h2>Procedimiento Paso a Paso</h2>
        
        <div class="step">
            <div class="step-number">1</div>
            <div class="step-content">
                <h3>Descargar la plantilla</h3>
                <p>Obtén el archivo Excel con el formato requerido desde el sistema:</p>
                <button style="background: #3498db; color: white; border: none; padding: 8px 15px; border-radius: 4px; cursor: pointer;">Descargar Plantilla</button>
                <p class="example">Formato del archivo: Productos_Carga_Masiva_YYYYMMDD.xlsx</p>
            </div>
        </div>
        
        <div class="step">
            <div class="step-number">2</div>
            <div class="step-content">
                <h3>Completar la plantilla</h3>
                <p>Ingresa los datos de tus productos siguiendo estas reglas:</p>
                
                <h4>Categorías</h4>
                <p>Utiliza el formato (Solo id de la categoría): <strong>ID</strong></p>
                <div class="example">
                    1: Moda<br>
                    2: Tecnología<br>
                    3: Accesorios<br>
                    4: Deportes<br>
                    5: Hogar<br>
                    6: Juguetes<br>
                    7: Transporte
                </div>
                
                <h4>Imágenes</h4>
                <p>Ingresa el nombre exacto del archivo de imagen (incluyendo extensión):</p>
                <div class="example">
                    producto_001.jpg<br>
                    monitor_pro.png<br>
                    silla_gamer_2023.webp
                </div>
            </div>
        </div>
        
        <div class="step">
            <div class="step-number">3</div>
            <div class="step-content">
                <h3>Cargar el archivo al sistema</h3>
                <p>Sube el archivo completado a través del módulo de carga masiva:</p>
                <div style="border: 2px dashed #ccc; padding: 20px; text-align: center; margin: 15px 0;">
                    [Área para arrastrar y soltar archivos]
                    <p>o</p>
                    <button style="background: #2ecc71; color: white; border: none; padding: 8px 15px; border-radius: 4px; cursor: pointer;">Seleccionar archivo</button>
                </div>
            </div>
        </div>
        
        <div class="step">
            <div class="step-number">4</div>
            <div class="step-content">
                <h3>Asociar imágenes</h3>
                <p>Para cada producto cargado, adjunta la imagen correspondiente:</p>
                <div class="example" style="display: flex; align-items: center; gap: 15px;">
                    <div>
                        <strong>Producto ID:</strong> 105<br>
                        <strong>Nombre:</strong> Teclado Mecánico<br>
                        <strong>Imagen esperada:</strong> teclado_x9.jpg
                    </div>
                    <input type="file" style="border: 1px solid #ddd; padding: 5px;">
                </div>
            </div>
        </div>
    </div>

    <div class="guide-section">
        <h2>Consideraciones Importantes</h2>
        <ul class="features">
            <li><strong>Solo una imagen por producto</strong> en carga masiva</li>
            <li>Archivos de imagen deben pesar menos de 2MB</li>
            <li>Formatos aceptados: JPG, PNG, WEBP</li>
            <li>Nombres de imagen sin caracteres especiales</li>
            <li>Verifica que los IDs de categoría existan</li>
            <li>No modifiques la estructura de columnas</li>
        </ul>
        
        <div class="note" style="margin-top: 20px;">
            <strong>Tip:</strong> Puedes descargar un reporte de categorías disponibles desde el menú "Herramientas → Exportar Categorías"
        </div>
    </div>

    <div class="guide-section" style="text-align: center; background: #e8f4fc;">
        <h2 style="color: #2980b9;">¿Necesitas ayuda?</h2>
        <p>Consulta nuestro centro de soporte o contacta al equipo técnico</p>
        <button style="background: #2980b9; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer;">Contactar Soporte</button>
    </div>
</body>
</html>