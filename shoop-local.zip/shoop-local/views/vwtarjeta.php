<div class="container kevin">

    <form action="">

        <div class="row">

            <div class="col">

                <h3 class="title">billing address</h3>

                <div class="inputBox">
                    <span>nombre completo:</span>
                    <input type="text" placeholder="john deo">
                </div>
                <div class="inputBox">
                    <span>email:</span>
                    <input type="email" placeholder="example@example.com">
                </div>
                <div class="inputBox">
                    <span>direccion:</span>
                    <input type="text" placeholder="room - street - locality">
                </div>
                <div class="inputBox">
                    <span>ciudad:</span>
                    <input type="text" placeholder="mumbai">
                </div>

                <div class="flex">
                    <div class="inputBox">
                        <span>pais:</span>
                        <input type="text" placeholder="india">
                    </div>
                    <div class="inputBox">
                        <span>codigo postal:</span>
                        <input type="text" placeholder="123 456">
                    </div>
                </div>

            </div>

            <div class="col">

                <h3 class="title">payment</h3>

                <div class="inputBox">
                    <span>acepatar tarejtas :</span>
                    <img src="IMG/tarjeta.png" alt="">
                </div>
                <div class="inputBox">
                    <span>nombre tarjeta:</span>
                    <input type="text" placeholder="mr. john deo">
                </div>
                <div class="inputBox">
                    <span>nombre tarjeta credito:</span>
                    <input type="number" placeholder="1111-2222-3333-4444">
                </div>
                <div class="inputBox">
                    <span>exp month :</span>
                    <input type="text" placeholder="january p">
                </div>

                <div class="flex">
                    <div class="inputBox">
                        <span>exp year :</span>
                        <input type="number" placeholder="2024">
                    </div>
                    <div class="inputBox">
                        <span>CVV :</span>
                        <input type="text" placeholder="1234">
                    </div>
                </div>

            </div>
    
        </div>

        <input id="pagar" type="submit" value="pagar" class="submit-btn">

    </form>

</div>    
