<footer class="row">
    <div class="col-sm-5 col">
        <div class="row">
            <div class="col bx-foot-info">
                <p>&copy; 2025 SHOOP. Todos los derechos reservados.</p>
            </div>

            <div class="col bx-foot-contact">
                <p>Contacto: <a href="mailto:soporte@shoop.com">soporte@shoop.com</a></p>
                <p>Teléfono: +57 123 456 7890</p>
            </div>

            <div class="col bx-foot-links">
                <ul>
                    <li><a href="<?= $isLoggedIn ? 'home.php?pg=5' : 'index.php?pg=5'; ?>">Sobre Nosotros</a></li>
                    <li><a href="/terms">Términos y Condiciones</a></li>
                    <li><a href="/privacy">Política de Privacidad</a></li>
                    <li><a href="<?= $isLoggedIn ? 'home.php?pg=8' : 'index.php?pg=8'; ?>"">Centro de Ayuda</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-sm-5 col">
                            <div class=" row">
                                <div class=" col bx-foot-newsletter">
                                    <p>Suscríbete para recibir novedades y ofertas:</p>
                                    <form>
                                        <input type="email" placeholder="Tu correo electrónico" required>
                                        <button type="submit">Suscribirse</button>
                                    </form>
                                </div>

                                <div class="col bx-foot-location">
                                    <p>Ubicación: Chía, Cundinamarca</p>
                                    <a href="https://www.google.com/maps?q=Cl.+25+%2311-135,+Ch%C3%ADa,+Cundinamarca"
                                        target="_blank">Ver en
                                        Google Maps</a>
                                </div>
                            </div>
            </div>
</footer>