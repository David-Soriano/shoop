<div class="bx-list-detped">
    <div>
        <h5>Pedido <span>0001</span></h5>
        <ul class="list-primary">
            <li>Número de guia
                <ul>
                    <li>GUI001-001</li>
                </ul>
            </li>
            <li>Productos
                <ul>
                    <li>Silla</li>
                    <li>Sofá</li>
                </ul>
            </li>
            <li>Cliente
                <ul>
                    <li>
                        David Soriano
                    </li>
                </ul>
            </li>
            <li>Ubicación
                <ul>
                    <li>Chia, cundinamarca</li>
                    <li>Calle 1 No 12-21</li>
                </ul>
            </li>
            <li>Valor por producto
                <ul>
                    <li>
                        $160400
                    </li>
                    <li>
                        $160400
                    </li>
                </ul>
            </li>
            <li>Valor Total
                <ul>
                    <li>
                        $320800
                    </li>
                </ul>
            </li>
            <li>Estado
                <ul>
                    <li>
                        Sin Enviar
                    </li>
                </ul>
            </li>
        </ul>
    </div>
</div>