<div class="col-5 bx-init">
    <h5>Bienvenido al panel de control</h5>
    <img src="../IMG/logistica.svg" alt="Logistica">
    <p id="bx-init_p-1">Aquí gestionará sus productos y pedidos de una manera facil y organizada.</p>
    <p id="bx-init_p-2">¡Todo en un solo lugar!</p>
</div>