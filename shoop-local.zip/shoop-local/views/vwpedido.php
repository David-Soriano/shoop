<div class="container-fluid">
	<div class="container">
		<div class="row">
			<div class="col-md-6 mx-auto cf-container">
				<form action="" method="post">
					<div class="cf-cover">
						<div class="session-title row">
							<h2>confirma tu pedido</h2>
							<p>verifica que tus datos esten corectos para realizar el envio </p>

							<div class="mb-3">
								<label for="disabledSelect" class="form-label">pais o region</label>
								<select id="disabledSelect" class="form-select">
									<option>pais</option>
									<option>colombia</option>
									<option>peru</option>
									<option>canada</option>
									<option>venezuela</option>
								</select>
								<div class="form-row row">
									<div class="col-md-6">
										<label for="">nombre completo(nombre y apellido)</label>
										<input type="text" required="" placeholder="ingresa tu nombre"
											class="form-control">
									</div>
									<div class="col-md-6">
										<label for="">Numero de telefono</label>
										<input type="text" placeholder="EJ:3124855147" class="form-control">
									</div>
								</div>
								<div>
									<div class="form-row row">
										<div class="col-md-6">
											<label for="">Dirección</label>
											<input type="text" placeholder=" EJ:Calle 11 Sur Número 23"
												class="form-control">
										</div>

										<div class="form-row row">
											<div class="col-md-6">
												<label for="">codigo postal</label>
												<input type="text" placeholder="EJ:251210" class="form-control">
											</div>
										</div>
										<div>
											<div class="form-row row">
												<div class="col-md-12">
													<label for="">ciudad</label>
													<input type="text" placeholder="EJ:BOGOTA" class="form-control">
												</div>
												<div class="form-row row">
													<div class="col-md-12">
														<label for="">codigo promocional</label>
														<input type="text" placeholder="EJ:AÑO2024"
															class="form-control">
													</div>
												</div>
												<div class="form-row row">
													<div class="col-md-12">
														<label for="">Email</label>
														<input type="text" placeholder="ingrese su Email"
															class="form-control">
													</div>
												</div>
												<div class="form-row row">
													<div class="col-md-12">
														<label for="">Message</label>
														<textarea
															placeholder="ESPECIFIQUE SI TIENE ALGUN PROBLEMA EN EL ENVIO"
															rows="3" class="form-control"></textarea>
													</div>
												</div>
												<div class="form-row row agre">
													<div class="col-md-12" id="agre">
														<p id="btn-t-c"><input type="checkbox"> <a
																href="index.php?pg=1015">Terminos y condiciones</a></p>
													</div>
												</div >
												<div class="btn-tajet">
													<a href="index.php?pg=10013" id="bt-confirmar">Confirmar</a>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>