<div class="container">
    <script src="https://cdn.commoninja.com/sdk/latest/commonninja.js" defer></script>
    <div class="commonninja_component pid-8e35ff34-ae97-437c-8bb1-232bd2035730"></div>
</div>