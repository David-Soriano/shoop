<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Política de Privacidad - Shoop</title>
    <link rel="stylesheet" href="../CSS/styles.css">
</head>
<body>
    <div class="header">
        <h1>Política de Privacidad de Shoop</h1>
        <div class="update-date">Última actualización: 30/03/2025</div>
    </div>

    <div class="policy-section">
        <p>Shoop valora la privacidad de sus usuarios y se compromete a proteger sus datos personales. Esta Política de Privacidad describe cómo recopilamos, utilizamos y protegemos la información de nuestros clientes en la ciudad de Chía, Cundinamarca.</p>
    </div>

    <div class="policy-section">
        <h2>1. Información que Recopilamos</h2>
        <p>Recopilamos la siguiente información cuando utilizas nuestra tienda virtual:</p>
        <ul>
            <li><strong>Datos personales:</strong> Nombre, correo electrónico, número de teléfono, dirección de envío.</li>
            <li><strong>Información de pago:</strong> Métodos de pago utilizados (sin almacenar datos bancarios completos).</li>
            <li><strong>Datos de navegación:</strong> Cookies, dirección IP, dispositivo utilizado y tiempo de conexión.</li>
        </ul>
    </div>

    <div class="policy-section">
        <h2>2. Uso de la Información</h2>
        <p>Utilizamos los datos recopilados para:</p>
        <ul>
            <li>Procesar pedidos y gestionar envíos.</li>
            <li>Brindar atención al cliente.</li>
            <li>Enviar comunicaciones promocionales (previa autorización del usuario).</li>
            <li>Mejorar la experiencia de compra y la seguridad de la plataforma.</li>
        </ul>
    </div>

    <div class="policy-section">
        <h2>3. Protección de la Información</h2>
        <p>Implementamos medidas de seguridad técnicas y organizativas para proteger la información personal de accesos no autorizados, pérdida o alteración.</p>
        
        <div class="highlight">
            <strong>Nota importante:</strong> Nunca solicitaremos contraseñas o información financiera completa por correo electrónico o teléfono.
        </div>
    </div>

    <div class="policy-section">
        <h2>4. Compartición de Datos</h2>
        <p>No vendemos ni compartimos información personal con terceros, excepto en los siguientes casos:</p>
        <ul>
            <li>Proveedores de servicios de pago y logística para cumplir con la entrega de pedidos.</li>
            <li>Autoridades legales si es requerido por ley.</li>
        </ul>
    </div>

    <div class="policy-section">
        <h2>5. Derechos del Usuario</h2>
        <p>Los usuarios pueden:</p>
        <ul>
            <li>Acceder, corregir o eliminar sus datos personales.</li>
            <li>Retirar su consentimiento para el uso de sus datos con fines promocionales.</li>
            <li>Solicitar la limitación o eliminación de sus datos conforme a la normativa vigente.</li>
        </ul>
        <p>Para ejercer estos derechos, contacta a nuestro equipo de soporte.</p>
    </div>

    <div class="policy-section">
        <h2>6. Cookies y Tecnologías de Rastreo</h2>
        <p>Utilizamos cookies para mejorar la navegación y personalizar la experiencia del usuario. Puedes configurar tu navegador para rechazar cookies, aunque esto podría afectar el funcionamiento del sitio.</p>
    </div>

    <div class="policy-section">
        <h2>7. Modificaciones a la Política de Privacidad</h2>
        <p>Nos reservamos el derecho de modificar esta política en cualquier momento. Notificaremos a los usuarios sobre cambios significativos a través de nuestro sitio web o correo electrónico.</p>
    </div>

    <div class="policy-section">
        <h2>8. Contacto</h2>
        <p>Para cualquier consulta sobre esta política, puedes contactarnos en:</p>
        <div class="contact-info">
            <strong>Correo electrónico:</strong> soporte@shoop.com<br>
    
        </div>
    </div>

    <div class="policy-section" style="text-align: center; font-style: italic;">
        <p>Al utilizar nuestra tienda virtual, aceptas los términos de esta Política de Privacidad.</p>
    </div>
</body>
</html>
