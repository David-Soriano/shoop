<?php
$host = "localhost";
$db = "if0_38462699_shoop";
$user = "root";
$pass = "";